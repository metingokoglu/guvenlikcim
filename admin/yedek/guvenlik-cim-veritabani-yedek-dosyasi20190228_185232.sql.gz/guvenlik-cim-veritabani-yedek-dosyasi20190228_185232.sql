CREATE DATABASE IF NOT EXISTS `arlinmzi_guvenlikcim`;

USE `arlinmzi_guvenlikcim`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `galeri`;

CREATE TABLE `galeri` (
  `galeri_id` int(11) NOT NULL AUTO_INCREMENT,
  `galeri_url` text NOT NULL,
  `galeri_aciklama` text NOT NULL,
  PRIMARY KEY (`galeri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

INSERT INTO `galeri` VALUES (1,"admin/images/galeri/MyApp5bc1003ee612e6.88315347.jpg",""),
(2,"admin/images/galeri/MyApp5bc1007f3a4b21.07625231.jpg",""),
(3,"admin/images/galeri/MyApp5bc100c44cde34.30110770.jpg",""),
(5,"admin/images/galeri/MyApp5bc2572bce8f09.55915735.jpg",""),
(6,"admin/images/galeri/MyApp5bc25740759d77.65047758.jpg",""),
(7,"admin/images/galeri/MyApp5bc257539d1359.54203544.jpg",""),
(8,"admin/images/galeri/MyApp5bc2575eb7d4f1.38572633.jpg",""),
(9,"admin/images/galeri/MyApp5bc257877a3da2.57432960.jpg",""),
(10,"admin/images/galeri/MyApp5bc25792634c46.42040837.jpg",""),
(11,"admin/images/galeri/MyApp5bc2579e9c3a70.37415880.jpg",""),
(12,"admin/images/galeri/MyApp5bc257b4f07e26.64131458.jpg",""),
(13,"admin/images/galeri/MyApp5bc257c2b43ab9.27269443.jpg",""),
(14,"admin/images/galeri/MyApp5bc257d0a58076.36682110.jpg",""),
(15,"admin/images/galeri/MyApp5bc257e403b918.05160267.jpg",""),
(16,"admin/images/galeri/MyApp5bc257eb7b1c85.91590232.jpg",""),
(17,"admin/images/galeri/MyApp5bc257fc6b13e4.11534798.jpg",""),
(18,"admin/images/galeri/MyApp5bc2581978f4e6.38789836.jpg",""),
(19,"admin/images/galeri/MyApp5bc258250e4ed2.58639671.jpg",""),
(20,"admin/images/galeri/MyApp5bc258468ab2b9.90687179.jpg",""),
(21,"admin/images/galeri/MyApp5bc25867b85577.32876725.jpg",""),
(22,"admin/images/galeri/MyApp5bc2587e8e7c25.06180070.jpg",""),
(25,"admin/images/galeri/WhatsApp Image 2019-02-18 at 22.15.07 (1).jpeg",""),
(26,"admin/images/galeri/WhatsApp Image 2019-02-18 at 22.15.08 (2).jpeg",""),
(27,"admin/images/galeri/20170721_183724.jpg",""),
(28,"admin/images/galeri/20170721_183738.jpg",""),
(29,"admin/images/galeri/IMG_20171022_164525.jpg",""),
(30,"admin/images/galeri/IMG-20170117-WA0010.jpeg",""),
(31,"admin/images/galeri/1506343555278.jpg","");


DROP TABLE IF EXISTS `mesajlar`;

CREATE TABLE `mesajlar` (
  `mesaj_id` int(11) NOT NULL AUTO_INCREMENT,
  `mesaj_isim` text CHARACTER SET utf8 NOT NULL,
  `mesaj_email` text CHARACTER SET utf8 NOT NULL,
  `mesaj_konu` text CHARACTER SET utf8 NOT NULL,
  `mesaj_mesaj` text CHARACTER SET utf8 NOT NULL,
  `mesaj_tarih` text CHARACTER SET utf8 NOT NULL,
  `mesaj_saat` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`mesaj_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `musteri_bilgisi`;

CREATE TABLE `musteri_bilgisi` (
  `musteri_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_kodu` text NOT NULL,
  `tarih` text NOT NULL,
  `musteri_adi` text NOT NULL,
  `telefon` text NOT NULL,
  `adres` text NOT NULL,
  `sistem` text NOT NULL,
  `marka` text NOT NULL,
  `model` text NOT NULL,
  `urun_bilgisi` text NOT NULL,
  `hdd` text NOT NULL,
  `sn_bilgisi` text NOT NULL,
  `ip_bilgisi` text NOT NULL,
  `port_bilgisi` text NOT NULL,
  `user1` text NOT NULL,
  `user2` text NOT NULL,
  `user3` text NOT NULL,
  `user4` text NOT NULL,
  `user5` text NOT NULL,
  `user6` text NOT NULL,
  `aciklama` text NOT NULL,
  `musteri_url` text NOT NULL,
  PRIMARY KEY (`musteri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `musteri_bilgisi` VALUES (1,1,"2017-03-04","Fiento Mobilya","0506 385 38 48","Dokuz Eylul Mh. 312/1 Sokak  Gaziemir İzmir","Kamera","Haikon",8,"7 kamera. 16 lı eskı musterı sıstemı var","1 TB","","192.168.1.220","85-8005","admin:Fiento16","user1:user12345","user2:user12345","servis:servis12345",":",":","Eskı dvr ıp : 192.168.1.200\r\nPort: 80-8000\r\nKullanıcı adı ve sıfreler haıkon 8 kanal ıle aynı\r\nModem kullanıcı adı:admin\r\nsifre:82101907","musteri/IMG_20181011_0033.jpg"),
(2,2,"2017-07-09","Kayral Oto Elektrik","0552 421 20 51","6.sanayi sitesi ana giriş ","Kamera","Neutron",8,"7 kamera","1 TB","","192.168.2.150","37770-95","admin:12345","user:12345","user1:12345","servis:12345",":",":","","musteri/"),
(3,3,"2017-08-20","Evren İletişim","0232 261 85 13","Zincirlikuyu caddesi bozyaka","Kamera","Neutron",4,"3 kamera ","1 TB","","192.168.2.160-- Dıs Ip : 78.189.161.134","37770-85","admin:12345","user:12345","user1:12345","888888:12345",":",":","Dsc Alarm panelı takıldı ","musteri/"),
(4,4,"2017-09-05","Zafertepe Aile Saglıgı Merkezi","0542 632 93 63","555 Sokak No:31 Zafertepe mah. Yaghaneler konak ızmır","Kamera","Neutron",4,"4 kamera","2 TB","415f09ad68667d0d","192.168.1.150","34567-80","admin:12345","user:12345","user1:12345","user2:12345","servis:12345",":","S/N ile verildi . ","musteri/"),
(5,5,"2017-11-12","Guzelyalı Otoparkı","0532 395 44 66","","Kamera","Beylerbeyi",8,"","320 GB","","","","admin:6161",":",":",":",":",":","","musteri/"),
(6,6,"2017-10-29","Mustafa Kavacık","0507 396 5761--İsmail bey: 0505 232 6812","Kavacık koyu izmir","Alarm Sistemi","Dsc","Diğer","3 pır 2 mk gsm modulu ","Diğer","","","",":",":",":",":",":",":","","musteri/"),
(7,7,"2017-11-04","Köksal Yılmaz","0530 469 04 02","Kavacık Koyu izmir","Kamera","Haikon",8,"","1 TB","","192.168.1.100- Dıs ıp: 5.11.164.206",9000,"admin:888888","user:888888",":",":",":",":","cenova 8 kanal cıhaz","musteri/"),
(8,8,"2017-11-10","Yılmaz Taşlama","0530 469 04 02","4.sanayi sitesi pınarbası izmir","Kamera","Diğer",8,"dahua dvr 8 kamera analog","1 TB","","192.168.1.108--dış ıp :151.250.212.180","95--37770","admin:12345","user:12345","user1:12345","user2:12345","888888:12345",":","","musteri/"),
(9,9,"2017-11-29","Modiz Mobilya","0546 629 16 06","çiftci petrol karsısı buca izmir ali cetmen","Kamera","Neutron",4,"","Diğer","","","",":",":",":",":",":",":","","musteri/"),
(10,10,"2017-03-20","Çınar Manav","0530 264 53 80","Cınartepe saglık ocagı yanı gultepe ızmır ali ","Kamera","Neutron",4,"","500 GB","","","","admin:admin",":",":",":",":",":","","musteri/"),
(12,11,"2017-11-22","Harman kuruyemiş","0553 661 35 71","ulastırma caddesi gaziemir izmir","Alarm Sistemi","Dsc","Diğer","2 pır ","Diğer","","","",":",":",":",":",":",":","","musteri/"),
(13,"012 ","","Mega oto yıkama","","","Kamera","Diğer",8,"japon dynamıc","500 GB","","","",":",":",":",":",":",":","","musteri/"),
(14,13,"2017-03-12","Doktoroglu Aktar","","havra sokagı izmir","Kamera","Neutron",8,"6 kamera 1 adet 360 derece ","1 TB","","","",":",":",":",":",":",":","","musteri/"),
(15,14,"2017-04-11","Mustafa Kavacık","","288/16 no 10 k:2 bucA izmir","Alarm Sistemi","Dsc","Diğer","1 pır 1 mk","Diğer","","","",":5555",":",":",":",":",":","","musteri/"),
(16,15,"2018-10-10","Cope Off Coffe","0544 721 76 74","kucukpark bornova izmir -armagan hanm","Kamera","Retro",8,"","1 TB","","","",":",":",":",":",":",":","cctv eye program\r\n0544 721 7674\r\nmavi23\r\n888888","musteri/"),
(17,"016 ","2018-04-03","Egemen Metal","Sedat Bey","641/1 sk. Karabaglar izmir","Kamera","Neutron",4,"3 kamera ","Diğer","d1eba78d4dbf56e0","192.168.1.100","95--37770","admin:12345","sedat:12345","888888:12345","servis:12345",":",":","s/n ile verildi nmss ahd","musteri/"),
(18,17,"2018-04-12","Karaca ","","Polat cad.Yesilyurt ziraat bank yanı","Kamera","Diğer",4,"entcam dvr rxcamwiev program var","500 GB","RSV1607002209468","192.168.0.150","80-9000","admin:boş","user1:12345678","user2:12345678",":",":",":","","musteri/"),
(19,18,"2018-06-11","Huseyın Aslan","","BALCOVA ","Kamera","Neutron",4,"nmss ahd","1 TB","f78638af3cff2373","","80-37770","admin:12345","888888:12345","yucel:12345","baskan:12345",":",":","sn ile verildi.","musteri/"),
(20,19,"2018-06-12","Huseyın Aslan-Villakent","","Villakent Seyrek İzmir","Kamera","Neutron",8,"nmss ahd","1 TB","8a0c8fafd6d670ae","","80-37770","admin:12345","yucel:12345","baskan:12345","servis:12345","user:12345",":","sn ile verildi","musteri/"),
(21,20,"","Mertkoz kozmetik","","","Kamera","Neutron",8,"","320 GB","","","",":",":",":",":",":",":","","musteri/"),
(22,2131,"80-20-9102","as","dasa","sad","Kamera","Neutron",4,"","320 GB","","","",":",":",":",":",":",":","","musteri/");


DROP TABLE IF EXISTS `musteri_bilgisi_yedek`;

CREATE TABLE `musteri_bilgisi_yedek` (
  `musteri_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_kodu` text NOT NULL,
  `tarih` text NOT NULL,
  `musteri_adi` text NOT NULL,
  `telefon` text NOT NULL,
  `adres` text NOT NULL,
  `sistem` text NOT NULL,
  `marka` text NOT NULL,
  `model` text NOT NULL,
  `urun_bilgisi` text NOT NULL,
  `hdd` text NOT NULL,
  `sn_bilgisi` text NOT NULL,
  `ip_bilgisi` text NOT NULL,
  `port_bilgisi` text NOT NULL,
  `user1` text NOT NULL,
  `user2` text NOT NULL,
  `user3` text NOT NULL,
  `user4` text NOT NULL,
  `user5` text NOT NULL,
  `user6` text NOT NULL,
  `aciklama` text NOT NULL,
  PRIMARY KEY (`musteri_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `referanslar`;

CREATE TABLE `referanslar` (
  `referans_id` int(11) NOT NULL AUTO_INCREMENT,
  `referans_url` text NOT NULL,
  `referans_baslik` text NOT NULL,
  `referans_yazi` text NOT NULL,
  PRIMARY KEY (`referans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

INSERT INTO `referanslar` VALUES (1,"admin/images/galeri/MyApp5bc0ffba06bbc9.78625900.jpg","AFYON İL EMNİYET MÜDÜRLÜĞÜ MOBESE","Plaka Okuma Kameraları"),
(2,"admin/images/galeri/MyApp5bc0ffc649c892.93738578.jpg","AFYONKARAHİSAR DEVLET HASTANESİ","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(3,"admin/images/galeri/MyApp5bc0ffd2a98ed0.14853748.jpg","AKHİSAR İLÇE EMNİYET","Ip Kamera ve Nvr Kayıt Sistemi"),
(4,"admin/images/galeri/MyApp5bc1ecaaab4411.65689487.jpg","EGE KOOP","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(5,"admin/images/galeri/MyApp5bc1e4f43b4fc2.71013347.jpg","AYDIN ADLİYESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(8,"admin/images/galeri/MyApp5bc1e68d5ae4f6.69921058.jpg","AYVALIK İLÇE EMNİYET MÜDÜRLÜĞÜ MOBESE SİSTEMİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(9,"admin/images/galeri/MyApp5bc1e6bfc8b814.03102705.jpg","BALIKESİR BÜYÜKŞEHİR BELEDİYESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(10,"admin/images/galeri/MyApp5bc1e6d894b8d5.47112308.jpg","BALIKESİR OTOYOL BELEDİYE PLAKA TANIMA SİSTEMİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(11,"admin/images/galeri/MyApp5bc1e6f9e74353.16343841.jpg","BALIKESİR SINDIRGI BELEDİYESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(12,"admin/images/galeri/MyApp5bc1e71e4549b9.57481168.jpg","BANVİT YAĞ FABRİKASI","Plaka Okuma Kameraları"),
(13,"admin/images/galeri/MyApp5bc1e74bb802f8.32528932.jpg","BP PETROL İSTASYONU","Ip Kamera ve Nvr Kayıt Sistemi"),
(14,"admin/images/galeri/MyApp5bc1e75d8257e5.90314097.jpg","BURDUR EMNİYET MÜDÜRLÜĞÜ IP KAMERA SİSTEMİ ( MOBESE )","Ip Kamera ve Nvr Kayıt Sistemi"),
(15,"admin/images/galeri/MyApp5bc1e78b2bd2b1.28887786.jpg","ÇEŞME DEVLET HASTANESİ","Analog Kamera ve Dvr Kayıt Sistemi"),
(16,"admin/images/galeri/MyApp5bc1e79db32298.79567826.jpg","DALAMAN EMNİYET MÜDÜRLÜĞÜ IP KAMERA SİSTEMİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(17,"admin/images/galeri/MyApp5bc1e7cda9cc45.49307834.jpg","GÖLHİSAR BURDUR İLÇE EMNİYET MÜDÜRLÜĞÜ","Plaka Okuma Kameraları"),
(18,"admin/images/galeri/MyApp5bc1e7ea403710.45325907.jpg","HAVA AMBULANS MERKEZİ İZMİR","Ip Kamera ve Nvr Kayıt Sistemi"),
(19,"admin/images/galeri/MyApp5bc1e84c3e2123.37993666.jpg","İZMİR SAHİL GÜVENLİK KOMUTANLIĞI","Ip Kamera ve Nvr Kayıt Sistemi"),
(20,"admin/images/galeri/MyApp5bc1e8687507c8.21747802.jpg","iZMİR SERBEST BÖLGE ESBAŞ GÜMRÜĞÜ","Ip Kamera ve Nvr Kayıt Sistemi"),
(21,"admin/images/galeri/MyApp5bc1e88682a731.24765216.jpg","İZMİR TÜM İLÇELER VE JANDARMA","Plaka Okuma Kameraları"),
(23,"admin/images/galeri/MyApp5bc1e8ecf33df9.47092545.jpg","KREDİ VE YURTLAR KURUMU BALIKESİR BANDIRMA BİNASI","Ip Kamera ve Nvr Kayıt Sistemi"),
(24,"admin/images/galeri/MyApp5bc1e90f42c7e6.17881864.jpg","MANİSA ORGANİZE SANAYİ BÖLGESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(25,"admin/images/galeri/MyApp5bc1e930066839.28003747.jpg","MENEMEN SSK HASTANESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(26,"admin/images/galeri/MyApp5bc1e94127c904.19333402.jpg","NAZİLLİ ADLİYESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(27,"admin/images/galeri/MyApp5bc1e9609b8fd1.73526230.jpg","ÖZSÜT","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(28,"admin/images/galeri/MyApp5bc1e99b09d060.86653523.jpg","TAVAS BELEDİYESİ İLÇE MEYDANI","Ip Kamera ve Nvr Kayıt Sistemi"),
(29,"admin/images/galeri/MyApp5bc1ea41a77113.68065645.jpg","ARLİN TEKSTİL TÜM SUBELER","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(30,"admin/images/galeri/MyApp5bc1eaa309a8a3.96765526.jpg","OKSİJEN ECZANESİ AGORA A.V.M İZMİR","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(31,"admin/images/galeri/MyApp5bc1eaf1cd2e96.18999441.jpg","ZAFERTEPE 22 NOLU AİLE SAĞLIĞI MERKEZİ","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(33,"admin/images/galeri/MyApp5bc1eb9ca533d4.13797272.jpg","SALON STILL GÖZTEPE","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(34,"admin/images/galeri/MyApp5bc1ec060abb29.46630262.jpg","GALATA ÇAYCISI İZMİR ŞUBELERİ","Analog Kamera ve Dvr Kayıt Sistemi"),
(36,"admin/images/galeri/MyApp5bc0ffe21702f3.80652261.jpg","ALAŞEHİR ADLİYESİ","Ip Kamera ve Nvr Kayıt Sistemi\r\n"),
(37,"admin/images/galeri/MyApp5bc1ed1eaf2724.23720560.jpg","FİENTO MOBİLYA ","AHD Kamera ve AHD Dvr Kayıt Sistemi"),
(38,"admin/images/galeri/MyApp5bc7983f23dd93.59935962.jpg","VESTEL GÜVENÜSSÜ İZMİR ŞUBESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(39,"admin/images/galeri/MyApp5bd08bae1eef36.51987742.jpg","VATAN VAKFI-İZMİR ŞUBESİ","Ip Kamera ve Nvr Kayıt Sistemi"),
(40,"admin/images/galeri/Adsız.jpg","COPE OF COFFEE","AHD KAMERA SİSTEMİ");


DROP TABLE IF EXISTS `urunler`;

CREATE TABLE `urunler` (
  `urunler_id` int(11) NOT NULL AUTO_INCREMENT,
  `urunler_url` text CHARACTER SET utf8 NOT NULL,
  `urunler_aciklama` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`urunler_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `urunler` VALUES (2,"admin/images/urunler/images (1).jpg","Analog,AHD,IP Kamera Sistemleri"),
(3,"admin/images/urunler/neutron-hirsiz-alarm-sistemleri-300x212.jpg","Hırsız Alarm Sistemleri"),
(4,"admin/images/urunler/yangin-alarm-sistemleri-1030x494.jpg","Yangın Alarm Sistemleri"),
(5,"admin/images/urunler/tuzla-akilli-ev-sistemleri.jpg","Akıllı Ev Otomasyon Sistemleri"),
(6,"admin/images/urunler/images.jpg","Ağ&Network Sistemleri"),
(7,"admin/images/urunler/goruntulu-diafon-sistemleri.jpg","Diafon Sistemleri"),
(8,"admin/images/urunler/18elr79ap40kpjpg.jpg","Fiber Optik Sistemler");


DROP TABLE IF EXISTS `uyeler`;

CREATE TABLE `uyeler` (
  `uye_id` int(11) NOT NULL AUTO_INCREMENT,
  `kullanici_adi` text NOT NULL,
  `sifre` text NOT NULL,
  `yetki` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uye_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `uyeler` VALUES (1,"emre","emre3535",1),
(2,"metin",123,1);


DROP TABLE IF EXISTS `yedek`;

CREATE TABLE `yedek` (
  `yedek_id` int(11) NOT NULL AUTO_INCREMENT,
  `dosya_yolu` text NOT NULL,
  `gonder` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`yedek_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `yedek` VALUES (17,"./guvenlik-cim-veritabani-yedek-dosyasi20190228_185222.sql.gz",0),
(16,"./guvenlik-cim-veritabani-yedek-dosyasi20190228_185206.sql.gz",0),
(15,"./guvenlik-cim-veritabani-yedek-dosyasi20190228_181132.sql.gz",0);


DROP TABLE IF EXISTS `yenikayit`;

CREATE TABLE `yenikayit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_adi` text NOT NULL,
  `telefon` text NOT NULL,
  `adres` text NOT NULL,
  `sistem` text NOT NULL,
  `sistem_tipi` text NOT NULL,
  `servis_nedeni` text NOT NULL,
  `talep_tarihi` text NOT NULL,
  `yapilis_tarihi` text NOT NULL,
  `alinacak_ucret` text NOT NULL,
  `alinan_ucret` text NOT NULL,
  `kalan_tutar` text NOT NULL,
  `kayit_url` text NOT NULL,
  `durum` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `yenikayit` VALUES (2,"Nesibe örs","","Dikili","Kamera","","DVR kayıt yapmıyor","2018-12-03","2018-12-06",1000,1000,0,"kayit/","Yapıldı"),
(3,"Uzun grup ","","Aliağa OPET ","Kamera","Neutron","Uzak izleme yapılamıyor","2018-12-04","2018-12-06","75 tl",75,0,"kayit/","Yapıldı"),
(4,"Toros camii","","Gültepe mezarlık yani ","Kamera","","Kamera sistemi keşfi","2018-12-04","2018-12-16",2600,2600,0,"kayit/","Yapıldı"),
(5,"Arlin tekstil depo","","Karabağlar","Network","Multitek star 2s","Dahili hat düzenleme \r\n","2018-12-03","2018-12-05",150,"",150,"kayit/","Yapıldı"),
(6,"Bostanlı kuaför","","Bostanlı pazar yeri yanı","Alarm Sistemi","Neutron","Alarm sistemi montajı","2018-12-04","2018-12-06",1000,1000,0,"kayit/","Yapıldı"),
(7,"Fiento Mobilya","","","Network","PC format","bılgısayar format","2019-01-11","2019-01-12",400,400,0,"kayit/","Yapıldı"),
(8,"mermercioğlu Apartmanı","","İzmir park yanı mermerci oglu apt.","Alarm Sistemi","Alarm ","Önder bey Alarm sistemi akü degişimi 12 v 7 a","2019-01-10","2019-01-12",120,120,0,"kayit/","Yapıldı"),
(9,"Mertkoz kozmetik","","Pınarbaşı","Kamera","","Cepten izleme yapılamıyor","2019-01-13","","","",0,"kayit/","Yapıldı"),
(10,"Köksal yılmaz","","Kavacık köyü","Kamera","","Alarm siren ilave kamera arızaları","2019-01-08","",600,"",600,"kayit/","Bekliyor"),
(11,"Arlin tekstil urla","","Urla mağazası","Kamera","Neutron","Ses modülü montajı. \r\nGenel topalrama ","2019-01-01","",150,"",150,"kayit/","Yapıldı"),
(12,"Arlin tekstil Torbalı ","","Torbalı","Kamera","","Ses modülü kamera yer değiştirme\r\n110 TL ses modülü\r\n150 TL servis\r\n","2019-01-12","2019-01-14",260,"",260,"kayit/","Yapıldı"),
(13,"Bora Bey Olımpıyat Evleri","","Olimpiyat Evleri uzundere izmir","Kamera","Ip Kamera sistemi ","Müşteride bulunan nvr 25.01.19 da müşteriden alındı.Mail kontrolleri yapılıp telefoına mail gonderimi yapılacak. Nvr ın calısması durumunda 5 adet ıp kamera lı montaj teklıfı verılecek.\r\nhaber verme tarıhı en gec 29.01.2019 olacak","2019-01-25","","","",0,"kayit/","Bekliyor"),
(14,"Tarkan Örs ","","Dikili izmir","Diğer","Merkez toparlama ","Müşterinin network ve kamera merkezinin oldugu kabin alanı toparlanacak. Çalışmayan kameralar devreye alınacak. Genel yapılacak olan ek işler oalabılır.Pks kanal ve farklı boyutlarda kanalların goturulmesi gerekiyor.Planlanan tarıh 2 subat ","2019-01-26","",800,"",800,"kayit/","Bekliyor"),
(15,"Yasin bey ","","Urla izmir","Kamera","Ahd kamera","Müşteriye ait 3 adet kamera montajı yapılacak.2 ADET ses nodülü takılacak.\r\nPlanlanan tarıh 29.01.19\r\nses modulu : 80 tl birim","2019-01-26","2019-01-28",310,310,0,"kayit/","Yapıldı"),
(16,"Arlin tekstil alasehir","","Alasehir sevgi yolu manısa","Diğer","Merkez toparlama ","Müşteri magazasında bulunan merkez alanı toparlama işleri.\r\nkanallarla gıdılmesı gerek.\r\nplanlanan tarıh : 29.01.2019\r\nservis: 200\r\nSes modulu : 150\r\nyol bedeli : 100\r\nek malzeme : 50","2019-01-25","",500,"",500,"kayit/","Yapıldı"),
(17,"Nesibe Örs","","Dikili","Kamera","Ahd kamera","Ecazeneye 1 adet kamera ilavesi isteği. Kameralarda yer degişimi .","2019-01-25","2019-01-26",270,270,0,"kayit/","Yapıldı"),
(18,"ANAFARTA TAKTİK","","Begos İzmir ","Yangın Alarm","Konvansiyonel ","Sistem, dedektör bakım\r\nYapılacak tarih :30.01.2019","2019-01-28","2019-01-30",200,"",200,"kayit/","Yapıldı"),
(19,"Hiç lokantası Urla","","","Kamera","Neutron ip","Sistem devreye alma","2019-02-04","",300,"",300,"kayit/","Bekliyor"),
(20,"Mustafa bey","","Şirinyer","Alarm Sistemi","Dsc","Panel taşıma işi","2019-02-01","","","",0,"kayit/","Yapıldı"),
(21,"Nesibe örs","","Dikili","Kamera","Neutron","Eczane HDD kontrol. Köy evi 4 li sistem montajı","2019-02-06","",2000,"",2000,"kayit/","Bekliyor"),
(22,"Fiento mobilya","","","Kamera","Neutron","Merkez taşıma işi","2019-02-04","",4500,"",4500,"kayit/","Bekliyor");


DROP TABLE IF EXISTS `yenikayit_yedek`;

CREATE TABLE `yenikayit_yedek` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_adi` text NOT NULL,
  `telefon` text NOT NULL,
  `adres` text NOT NULL,
  `sistem` text NOT NULL,
  `sistem_tipi` text NOT NULL,
  `servis_nedeni` text NOT NULL,
  `talep_tarihi` text NOT NULL,
  `yapilis_tarihi` text NOT NULL,
  `alinacak_ucret` text NOT NULL,
  `alinan_ucret` text NOT NULL,
  `kalan_tutar` text NOT NULL,
  `kayir_url` text NOT NULL,
  `durum` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `yenikayit_yedek` VALUES (1,"metin GÖKOĞLU",5512201676,"555 sokak no:70 konak/izmir","Kamera","4 lü","boş","2018-12-03","2018-12-05",400,0,400,"","Bekliyor"),
(2,"Nesibe örs","","Dikili","Kamera","","DVR kayıt yapmıyor","2018-12-03","","","",0,"","Bekliyor"),
(3,"Uzun grup ","","Aliağa OPET ","Kamera","Neutron","Uzak izleme yapılamıyor","2018-12-04","","75 tl","",75,"","Bekliyor"),
(4,"Toros camii","","Gültepe mezarlık yani ","Kamera","","Kamera sistemi keşfi","2018-12-04","","","",0,"","Bekliyor"),
(5,"Arlin tekstil","","Karabağlar","Network","Multitek star 2s","Dahili hat düzenleme \r\n","2018-12-03","","","",0,"","Bekliyor"),
(6,"Bostanlı kuaför","","Bostanlı pazar yeri yanı","Alarm Sistemi","","Alarm sistemi keşfi","2018-12-04","","","",0,"","Bekliyor"),
(7,"metin",5512201676,"asasf","Bekliyor","neutron","saadf","2018-12-05","2018-12-05",1500,500,1000,"",""),
(8,"SDASDA","saddsa","SADSDA","Kamera","sadsa","saddsa","2019-01-01","2019-01-20",222,22,200,"","Yapıldı");


SET foreign_key_checks = 1;
